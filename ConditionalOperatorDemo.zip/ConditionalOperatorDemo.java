class ConditionalOperatorDemo{
	
	public static void main(String[] args){
		
		String res=(5<6)?"Hi":"Bye";
		System.out.println(res);
		int a=9;
		String res1= (a%2==0)?"even":"bye";
		System.out.println(res1);
		
	}
	
}